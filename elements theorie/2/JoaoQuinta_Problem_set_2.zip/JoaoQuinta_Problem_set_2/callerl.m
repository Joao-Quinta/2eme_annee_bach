% Joao Quinta

N = 1000;

%task 2
mx = [0;0];
kxx = [1,0.8;0.8,1];
vec = GenCodeMultiGaus(N, mx, kxx)

mz = [0;0];

kzz1 = [0.1,0;0,0.1];
vecz1 = GenCodeMultiGaus(N, mz, kzz1);
y1 = vec + vecz1;
figure
hold on 
plot(vec(:,1),vec(:,2),'+');
plot(y1(:,1),y1(:,2),'o');
hold off

kzz2 = [0.5,0;0,0.5];
vecz2 = GenCodeMultiGaus(N, mz, kzz2);
y2 = vec + vecz2;
figure
hold on 
plot(vec(:,1),vec(:,2),'+');
plot(y2(:,1),y2(:,2),'o');
hold off

kzz3 = [1,0;0,1];
vecz3 = GenCodeMultiGaus(N, mz, kzz3);
y3 = vec + vecz3;
figure
hold on 
plot(vec(:,1),vec(:,2),'+');
plot(y3(:,1),y3(:,2),'o');
hold off

kzz4 = [2,0;0,2];
vecz4 = GenCodeMultiGaus(N, mz, kzz4);
y4 = vec + vecz4;
figure
hold on 
plot(vec(:,1),vec(:,2),'+');
plot(y4(:,1),y4(:,2),'o');
hold off

kzz5 = [10,0;0,10];
vecz5 = GenCodeMultiGaus(N, mz, kzz5);
y5 = vec + vecz5;
figure
hold on 
plot(vec(:,1),vec(:,2),'+');
plot(y5(:,1),y5(:,2),'o');
hold off


