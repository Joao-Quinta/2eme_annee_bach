package magasinComplement;

public class ProduitNonIdoine {
	
	private int pRiX;
	private int pOiDsEnGrAmMeS;
	private String nOmCoMpLeT;
	public ProduitNonIdoine(int prix, int poidsEnGrammes, String nomComplet) {
		this.pRiX = prix;
		this.pOiDsEnGrAmMeS = poidsEnGrammes;
		this.nOmCoMpLeT = nomComplet;
	}
	public int getpRiX() {
		return pRiX;
	}
	public void setpRiX(int prix) {
		this.pRiX = prix;
	}
	public int getpOiDsEnGrAmMeS() {
		return pOiDsEnGrAmMeS;
	}
	public void setpOiDsEnGrAmMeS(int poidsEnGrammes) {
		this.pOiDsEnGrAmMeS = poidsEnGrammes;
	}
	public String getnOmCoMpLeT() {
		return nOmCoMpLeT;
	}
	public void setnOmCoMpLeT(String nomComplet) {
		this.nOmCoMpLeT = nomComplet;
	}

}
