package magasinComplement;

public class ProduitPerissableNonIdoine extends ProduitNonIdoine {
	private String dAtEdEpErEmPtIoN;

	public ProduitPerissableNonIdoine(int prix, int poidsEnGrammes, String nomComplet, String dateDePeremption) {
		super(prix, poidsEnGrammes, nomComplet);
		this.dAtEdEpErEmPtIoN = dateDePeremption;
	}

	public String getdAtEdEpErEmPtIoN() {
		return dAtEdEpErEmPtIoN;
	}

	public void setdAtEdEpErEmPtIoN(String dateDePeremption) {
		this.dAtEdEpErEmPtIoN = dateDePeremption;
	}
}
