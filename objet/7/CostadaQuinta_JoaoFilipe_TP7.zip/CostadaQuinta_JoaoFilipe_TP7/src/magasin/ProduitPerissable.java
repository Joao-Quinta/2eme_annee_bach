package magasin;

public class ProduitPerissable extends Produit {
	
	private String dateDePeremption;

	public ProduitPerissable(int prix, int poidsEnGrammes, String nomComplet, String dateDePeremption) {
		super(prix, poidsEnGrammes, nomComplet);
		this.dateDePeremption = dateDePeremption;
	}

	public String getDateDePeremption() {
		return dateDePeremption;
	}

	public void setDateDePeremption(String dateDePeremption) {
		this.dateDePeremption = dateDePeremption;
	}
	
	

}
