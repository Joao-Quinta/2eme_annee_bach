package magasin;

public class Produit {
	
	private int prix;
	private int poidsEnGrammes;
	private String nomComplet;
	public Produit(int prix, int poidsEnGrammes, String nomComplet) {
		super();
		this.prix = prix;
		this.poidsEnGrammes = poidsEnGrammes;
		this.nomComplet = nomComplet;
	}
	public int getPrix() {
		return prix;
	}
	public void setPrix(int prix) {
		this.prix = prix;
	}
	public int getPoidsEnGrammes() {
		return poidsEnGrammes;
	}
	public void setPoidsEnGrammes(int poidsEnGrammes) {
		this.poidsEnGrammes = poidsEnGrammes;
	}
	public String getNomComplet() {
		return nomComplet;
	}
	public void setNomComplet(String nomComplet) {
		this.nomComplet = nomComplet;
	}
	
	

}
