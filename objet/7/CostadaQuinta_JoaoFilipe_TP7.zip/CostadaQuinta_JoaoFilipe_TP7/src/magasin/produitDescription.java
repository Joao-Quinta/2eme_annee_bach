package magasin;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import magasinComplement.ProduitNonIdoine;
import magasinComplement.ProduitPerissableNonIdoine;

public class produitDescription {

	static void decrireProduit(ProduitNonIdoine p) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		
		Method[] methodList = p.getClass().getDeclaredMethods();
		
		for (Method method: methodList) {
			if (method.getParameters().length > 0) {
				}else {
			
			System.out.println(""+ method.getName() + " returned " + method.invoke(p, null));	
			Object x = method.invoke(p, null);
			}}
			
		}
		
		
	
	static void decrireProduitPerissable(ProduitPerissableNonIdoine p) throws IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Class<?> x = p.getClass().getSuperclass();
		
		Method[] methodList = p.getClass().getDeclaredMethods();
		
		for (Method method: methodList) {
			if (method.getParameters().length > 0) {}else {
			System.out.println(""+ method.getName() + " returned " + method.invoke(p, null));}
		}
		
		Method[] methodListSuper = x.getDeclaredMethods();
		for (Method methodSuper: methodListSuper) {
			if (methodSuper.getParameters().length > 0) {}else {
			System.out.println(""+ methodSuper.getName() + " returned " + methodSuper.invoke(p, null));}
		}
		
		
	}
	
	static Produit instancierProduit(String nom, int poids, int prix) {
		Produit produit = new Produit(prix, poids, nom);
		return produit;
	};
	static ProduitPerissable instancierProduitPerissable(String nom, int poids, int prix, String date) {
		ProduitPerissable produitPerissable = new ProduitPerissable(prix, poids, nom, date);
		return produitPerissable;
	};
	

}
