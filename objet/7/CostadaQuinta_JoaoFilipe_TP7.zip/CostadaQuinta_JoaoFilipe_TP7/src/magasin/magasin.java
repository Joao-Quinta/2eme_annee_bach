package magasin;
import magasin.produitDescription;
import magasinComplement.ProduitNonIdoine;
import magasinComplement.ProduitPerissableNonIdoine;

public class magasin {
	public static void main(String[] args) throws Exception{
		
		//on cree un produit qui porte les valeurs 2,4, beurre -> prix, poids, nom
		System.out.println("on a cree un produit, qui coute 2, pese 4, et s'appelle beurre");
		System.out.println();
		ProduitNonIdoine produit1 = new ProduitNonIdoine(2,4,"beurre");
		produitDescription.decrireProduit(produit1);
		System.out.println();
		
		//on cree un produitPerissable qui porte les valeurs 3, 10, lait, 10/13/2029 -> prix, poids, nom, date
		System.out.println("on a cree un produit, qui coute 3, pese 10, s'appelle lait, et a comme de date de peromption 10/13/2029");
		System.out.println();
		ProduitPerissableNonIdoine produit2 = new ProduitPerissableNonIdoine(3,10,"lait","10/13/2029");
		produitDescription.decrireProduitPerissable(produit2);
		System.out.println();
		
		//on cree un produit avc le constructeur idoine qui porte les valeurs 2,4, beurre -> prix, poids, nom
		System.out.println("on a cree un produit, qui coute 2, pese 4, et s'appelle beurre");
		System.out.println();
		Produit produit = new Produit(2,4,"beurre");
		System.out.println("voici le prix : "+ produit.getPrix() + " _ voici le poids: "+ produit.getPoidsEnGrammes()+ " _ voici le nom: "+ produit.getNomComplet());
		System.out.println();
		
		//on cree un produitPerissable avc constructeur idoine qui porte les valeurs 3, 10, lait, 10/13/2029 -> prix, poids, nom, date
		System.out.println("on a cree un produit, qui coute 3, pese 10, s'appelle lait, et a comme de date de peromption 10/13/2029");
		System.out.println();
		ProduitPerissable produitPerissable = new ProduitPerissable(3,10,"lait","10/13/2029");
		System.out.println("voici le prix : "+ produitPerissable.getPrix() + " _ voici le poids: "+ produitPerissable.getPoidsEnGrammes()+ " _ voici le nom: "+ produitPerissable.getNomComplet() + " _ voici la date: "+ produitPerissable.getDateDePeremption());
		System.out.println();
		
	}	

}

