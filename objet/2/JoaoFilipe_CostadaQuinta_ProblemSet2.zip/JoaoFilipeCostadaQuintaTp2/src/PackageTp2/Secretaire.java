package PackageTp2;

public class Secretaire extends Staff {
	private int anci ;

	public Secretaire(String nom_, int age_, int anci_) {
		super(nom_, age_);
		this.anci = anci_;
	}

	@Override
	double getSalaire() {
		return this.anci*10;
	}
	
	
	//GETTERS & SETTERS
	public int getAnci() {
		return anci;
	}

	public void setAnci(int anci) {
		this.anci = anci;
	}

}
