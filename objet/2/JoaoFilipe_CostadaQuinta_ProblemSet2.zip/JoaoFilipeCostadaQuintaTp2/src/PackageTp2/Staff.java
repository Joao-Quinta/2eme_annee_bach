package PackageTp2;

abstract class Staff extends Employe {

	public Staff(String nom_, int age_) {
		super(nom_, age_);
		// TODO Auto-generated constructor stub
	}

}
