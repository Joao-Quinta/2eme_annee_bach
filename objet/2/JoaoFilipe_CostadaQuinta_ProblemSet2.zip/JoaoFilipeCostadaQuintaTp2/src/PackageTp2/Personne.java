package PackageTp2;

public class Personne {
	
	private String nom;
	private int age;
	
	public Personne (String nom_, int age_) {
		this.setNom(nom_);
		this.setAge(age_);		
	}
	
	
	
	
	
	
	//GETTERS & SETTERS
	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

}
