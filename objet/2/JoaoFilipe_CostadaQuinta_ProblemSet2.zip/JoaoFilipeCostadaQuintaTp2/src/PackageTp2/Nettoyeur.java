package PackageTp2;

public class Nettoyeur extends Staff {

	public Nettoyeur(String nom_, int age_) {
		super(nom_, age_);
	}

	@Override
	double getSalaire() {
		return 99;
	}

}
