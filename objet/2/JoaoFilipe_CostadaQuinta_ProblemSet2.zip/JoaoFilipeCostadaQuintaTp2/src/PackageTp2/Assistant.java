package PackageTp2;

public class Assistant extends Employe {
	private int taux ;

	public Assistant(String nom_, int age_, int taux_) {
		super(nom_, age_);
		this.setTaux(taux_);
		
	}

	@Override
	double getSalaire() {
		return (int)(((float)this.taux/(float)100)*66);
	}
	
	
	
	//GETTERS & SETTERS
	public int getTaux() {
		return taux;
	}

	public void setTaux(int taux) {
		this.taux = taux;
	}
}
