package PackageTp2;

abstract class Employe extends Personne {
	public Employe(String nom_, int age_) {
		super(nom_, age_);
	}

	abstract double getSalaire();

}
