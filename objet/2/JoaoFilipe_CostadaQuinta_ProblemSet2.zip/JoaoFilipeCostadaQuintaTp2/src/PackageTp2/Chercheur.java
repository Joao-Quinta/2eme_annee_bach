package PackageTp2;

import java.util.Arrays;

public class Chercheur extends Employe {
	private int[] citations;

	public Chercheur(String nom_, int age_, int[] citations_) {
		super(nom_, age_);
		this.setCitations(citations_);
	}

	@Override
	double getSalaire() {
		return 10*this.compute_h_index();
	}
	
	
	@SuppressWarnings("unused")
	private int compute_h_index () {
		// citations is a attribute ( private int [])
		Arrays.sort (citations) ;
		int [] minArr = new int [citations.length];
		for (int i = citations.length -1; i >=0; i --) {
			minArr [ i ] = Math.min ( citations [ i ] , citations.length - i);
		}
		Arrays.sort (minArr);
		// minArr is sorted -> max is at the end
		int maxVal = minArr [minArr.length - 1];
		return maxVal ;
	}
	
	
	
	//GETTERS & SETTERS
	public int[] getCitations() {
		return citations;
	}

	public void setCitations(int[] citations) {
		this.citations = citations;
	}

}
