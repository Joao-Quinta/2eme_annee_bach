package PackageTp2;

public class Startup {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		
		//Creer un objet par personne
		Employe prof = new Professeur (" Philippe ", 64) ;
		Employe assistant = new Assistant (" Oscar ", 33 , 80) ;
		Employe chercheur1 = new Chercheur (" Alan ", 41 , new int []{10 ,8 ,5 ,4 ,3});
		Employe chercheur2 = new Chercheur (" Claude ", 84 , new int []{25 ,8 ,5 ,3 ,3});
		Staff secretaire = new Secretaire (" John ", 53 , 5) ;
		Staff nettoyeur = new Nettoyeur (" George ", 49) ;
		Etudiant etud1 = new Etudiant (" Ada", 36) ;
		Etudiant etud2 = new Etudiant (" Charles ", 25) ;
		
		System.out.println("salaire" + prof.getNom() + ": " + prof.getSalaire());
		System.out.println("salaire" + assistant.getNom() + ": " + assistant.getSalaire());
		System.out.println("salaire" + chercheur1.getNom() + ": " + chercheur1.getSalaire());
		System.out.println("salaire" + chercheur2.getNom() + ": " + chercheur2.getSalaire());
		System.out.println("salaire" + secretaire.getNom() + ": " + secretaire.getSalaire());
		System.out.println("salaire" + nettoyeur.getNom() + ": " + nettoyeur.getSalaire());
		
		//Compute total salary amount
		Employe [] employes = new Employe [] { prof , assistant , chercheur1 , chercheur2 , secretaire , nettoyeur };
		//for (int i = citations.length -1; i >=0; i --);
		double salaireTotal = 0;
		for (int i = 0; i < employes.length; i ++) {
			salaireTotal = salaireTotal + employes[i].getSalaire();		
		}
		System.out.println("==> salaire total : " + salaireTotal);
		
		
		
		
		
		System.out.println();
		
		
		
		
		System.out.println("age" + prof.getNom() + ": " + prof.getAge());
		System.out.println("age" + assistant.getNom() + ": " + assistant.getAge());
		System.out.println("age" + chercheur1.getNom() + ": " + chercheur1.getAge());
		System.out.println("age" + chercheur2.getNom() + ": " + chercheur2.getAge());
		System.out.println("age" + secretaire.getNom() + ": " + secretaire.getAge());
		System.out.println("age" + nettoyeur.getNom() + ": " + nettoyeur.getAge());
		System.out.println("age" + etud1.getNom() + ": " + etud1.getAge());
		System.out.println("age" + etud2.getNom() + ": " + etud2.getAge());
		
		// Compute average age among people
		Personne [] personnes = new Personne [] { prof , assistant , chercheur1 , chercheur2 , secretaire , nettoyeur , etud1 , etud2 };
		double ageMoyen = 0;
		for (int i = 0; i < personnes.length; i ++) {
			ageMoyen = ageMoyen + personnes[i].getAge();		
		}
		ageMoyen = (int)(ageMoyen / personnes.length);
		System.out.println("==> age moyen : " + ageMoyen);
		

	}

}
