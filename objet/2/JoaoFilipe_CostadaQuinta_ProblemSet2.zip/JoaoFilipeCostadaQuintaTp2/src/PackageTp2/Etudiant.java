package PackageTp2;

public class Etudiant extends Personne {

	public Etudiant(String nom_, int age_) {
		super(nom_, age_);
		// TODO Auto-generated constructor stub
	}
	

}
