package PackageTp2;

public class Professeur extends Employe {

	public Professeur(String nom_, int age_) {
		super(nom_, age_);
		// TODO Auto-generated constructor stub
	}

	@Override
	double getSalaire() {
		return 100*Math.sqrt(getAge());
	}

}
